from database import connect_db


def get_dashboard_stats():

    conn=connect_db()

    cursor=conn.cursor()


    cursor.execute(

    "SELECT COUNT(*) FROM candidates"

    )

    total=cursor.fetchone()[0]


    cursor.execute("""

    SELECT COUNT(*)

    FROM candidates

    WHERE suitability='Highly Suitable'

    """)

    eligible=cursor.fetchone()[0]


    cursor.execute("""

    SELECT COUNT(*)

    FROM candidates

    WHERE cluster_group='Industry Ready'

    """)

    ready=cursor.fetchone()[0]


    cursor.execute("""

    SELECT AVG(final_score)

    FROM candidates

    """)

    average=cursor.fetchone()[0]


    conn.close()


    if average is None:

        average=0


    return {

    "total":total,

    "eligible":eligible,

    "ready":ready,

    "average":round(average)

    }