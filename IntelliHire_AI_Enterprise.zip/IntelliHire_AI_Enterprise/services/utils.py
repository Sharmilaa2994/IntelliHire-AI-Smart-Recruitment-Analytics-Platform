def recommendation_engine(

cgpa,

technical,

communication,

projects

):

    recommendations=[]


    if cgpa<7:

        recommendations.append(

        "Improve Academic Performance"

        )


    if technical<7:

        recommendations.append(

        "Improve Technical Skills"

        )


    if communication<7:

        recommendations.append(

        "Improve Communication Skills"

        )


    if projects<3:

        recommendations.append(

        "Build More Projects"

        )


    if len(recommendations)==0:

        recommendations.append(

        "Excellent Candidate Profile"

        )


    return recommendations