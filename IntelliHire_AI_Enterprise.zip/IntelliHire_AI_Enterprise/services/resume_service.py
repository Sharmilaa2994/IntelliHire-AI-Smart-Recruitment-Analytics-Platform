from pypdf import PdfReader


skill_database=[

"python",

"html",

"css",

"javascript",

"sql",

"flask",

"numpy",

"pandas",

"machine learning",

"bootstrap"

]


def analyze_resume(filepath):

    reader=PdfReader(

    filepath

    )

    text=""


    for page in reader.pages:

        extracted=page.extract_text()

        if extracted:

            text+=extracted.lower()


    skills=[]


    for skill in skill_database:

        if skill in text:

            skills.append(

            skill

            )


    score=min(

    len(skills)*10,

    100

    )


    return score,skills