import pandas as pd

from database import connect_db


def export_excel():

    conn=connect_db()

    query="""

    SELECT *

    FROM candidates

    """

    df=pd.read_sql_query(

    query,

    conn

    )

    conn.close()

    output="reports/candidate_report.xlsx"

    df.to_excel(

    output,

    index=False

    )

    return output