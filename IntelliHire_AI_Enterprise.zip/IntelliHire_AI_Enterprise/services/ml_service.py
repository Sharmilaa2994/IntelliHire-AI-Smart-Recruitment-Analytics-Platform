import joblib

import config


scaler=joblib.load(

f"{config.MODEL_FOLDER}/scaler.pkl"

)

model=joblib.load(

f"{config.MODEL_FOLDER}/best_model.pkl"

)

kmeans=joblib.load(

f"{config.MODEL_FOLDER}/kmeans.pkl"

)


def predict_candidate(values):

    scaled=scaler.transform(

    values

    )

    prediction=model.predict(

    scaled

    )

    cluster=kmeans.predict(

    scaled

    )

    return prediction,cluster