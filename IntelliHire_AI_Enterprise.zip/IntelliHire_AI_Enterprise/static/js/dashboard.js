document.addEventListener(

'DOMContentLoaded',

()=>{

console.log(

'IntelliHire AI Started'

);

});