import pandas as pd

import random

data=[]

for i in range(1000):

    cgpa=round(

    random.uniform(

    5.5,

    10

    ),

    1

    )

    technical=random.randint(

    1,

    10

    )

    aptitude=random.randint(

    1,

    10

    )

    communication=random.randint(

    1,

    10

    )

    projects=random.randint(

    0,

    5

    )

    certifications=random.randint(

    0,

    5

    )

    github=random.randint(

    0,

    10

    )

    linkedin=random.randint(

    0,

    10

    )

    score=(

    cgpa*10+

    technical*5+

    aptitude*5+

    communication*5+

    projects*4+

    certifications*4+

    github*3+

    linkedin*3

    )

    suitability=1 if score>=170 else 0

    data.append([

    f"Candidate_{i+1}",

    cgpa,

    technical,

    aptitude,

    communication,

    projects,

    certifications,

    github,

    linkedin,

    suitability

    ])

columns=[

"Name",

"CGPA",

"Technical",

"Aptitude",

"Communication",

"Projects",

"Certifications",

"Github",

"Linkedin",

"Suitability"

]

df=pd.DataFrame(

data,

columns=columns

)

df.to_csv(

"dataset/candidate_dataset.csv",

index=False

)

print(

"Dataset Generated"

)