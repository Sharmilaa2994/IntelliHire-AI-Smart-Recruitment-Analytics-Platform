import sqlite3

import config


def connect_db():

    conn = sqlite3.connect(
        config.DATABASE_PATH
    )

    conn.row_factory = sqlite3.Row

    return conn


def create_tables():

    conn = connect_db()

    cursor = conn.cursor()

    cursor.execute("""

    CREATE TABLE IF NOT EXISTS users(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    full_name TEXT NOT NULL,

    email TEXT UNIQUE NOT NULL,

    password TEXT NOT NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

    )

    """)

    cursor.execute("""

    CREATE TABLE IF NOT EXISTS candidates(

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    candidate_name TEXT,

    cgpa REAL,

    technical INTEGER,

    aptitude INTEGER,

    communication INTEGER,

    projects INTEGER,

    certifications INTEGER,

    github INTEGER,

    linkedin INTEGER,

    final_score INTEGER,

    suitability TEXT,

    cluster_group TEXT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

    )

    """)

    conn.commit()

    conn.close()


if __name__=="__main__":

    create_tables()

    print(

    "Database created"

    )