import os

BASE_DIR = os.path.abspath(
    os.path.dirname(__file__)
)

SECRET_KEY = "intellihire_ai_2026"

DATABASE_PATH = os.path.join(
    BASE_DIR,
    "database",
    "candidate.db"
)

UPLOAD_FOLDER = os.path.join(
    BASE_DIR,
    "uploads"
)

REPORT_FOLDER = os.path.join(
    BASE_DIR,
    "reports"
)

MODEL_FOLDER = os.path.join(
    BASE_DIR,
    "models"
)

DATASET_PATH = os.path.join(
    BASE_DIR,
    "dataset",
    "candidate_dataset.csv"
)