import os
import joblib
import pandas as pd

from sklearn.model_selection import train_test_split

from sklearn.preprocessing import StandardScaler

from sklearn.neighbors import KNeighborsClassifier

from sklearn.linear_model import LogisticRegression

from sklearn.tree import DecisionTreeClassifier

from sklearn.ensemble import RandomForestClassifier

from sklearn.cluster import KMeans

from sklearn.metrics import accuracy_score


os.makedirs(

"models",

exist_ok=True

)


data=pd.read_csv(

"dataset/candidate_dataset.csv"

)


X=data.drop(

["Name","Suitability"],

axis=1

)

y=data["Suitability"]


X_train,X_test,y_train,y_test=\
train_test_split(

X,

y,

test_size=0.2,

random_state=42

)


scaler=StandardScaler()

X_train=scaler.fit_transform(

X_train

)

X_test=scaler.transform(

X_test

)

X_all=scaler.transform(

X
)


joblib.dump(

scaler,

"models/scaler.pkl"

)


models={

"KNN":KNeighborsClassifier(),

"Logistic":LogisticRegression(

max_iter=1000

),

"DecisionTree":DecisionTreeClassifier(),

"RandomForest":RandomForestClassifier()

}


best_model=None

best_accuracy=0


for name,model in models.items():

    model.fit(

    X_train,

    y_train

    )

    prediction=model.predict(

    X_test

    )

    accuracy=accuracy_score(

    y_test,

    prediction

    )

    print(

    name,

    accuracy

    )

    joblib.dump(

    model,

    f"models/{name}.pkl"

    )

    if accuracy>best_accuracy:

        best_accuracy=accuracy

        best_model=model


joblib.dump(

best_model,

"models/best_model.pkl"

)


kmeans=KMeans(

n_clusters=3,

n_init=10,

random_state=42

)

kmeans.fit(

X_all

)

joblib.dump(

kmeans,

"models/kmeans.pkl"

)


print(

"Training Complete"

)