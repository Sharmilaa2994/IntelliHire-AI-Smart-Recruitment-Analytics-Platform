from flask import Flask
from flask import render_template
from flask import request
from flask import redirect
from flask import flash
from flask import session

import os

import config

from database import connect_db

from services.auth_service import hash_password
from services.auth_service import verify_password

from services.ml_service import predict_candidate

from services.resume_service import analyze_resume

from services.analytics_service import get_dashboard_stats

from services.utils import recommendation_engine

app = Flask(__name__)

app.secret_key = config.SECRET_KEY

app.config['UPLOAD_FOLDER'] = config.UPLOAD_FOLDER


# ---------------- HOME ----------------

@app.route('/')

def home():

    return redirect('/login')


# ---------------- LOGIN ----------------

@app.route('/login', methods=['GET', 'POST'])

def login():

    if request.method == 'POST':

        email = request.form['email']

        password = request.form['password']

        conn = connect_db()

        cursor = conn.cursor()

        cursor.execute(

        '''

        SELECT *

        FROM users

        WHERE email=?

        ''',

        (email,)

        )

        user = cursor.fetchone()

        conn.close()

        if user:

            if verify_password(

            password,

            user['password']

            ):

                session['user'] = email

                return redirect('/dashboard')

        flash(

        'Invalid credentials'

        )

    return render_template(

    'login.html'

    )


# ---------------- REGISTER ----------------

@app.route(

'/register',

methods=['GET', 'POST']

)

def register():

    if request.method == 'POST':

        full_name = request.form['full_name']

        email = request.form['email']

        password = hash_password(

        request.form['password']

        )

        conn = connect_db()

        cursor = conn.cursor()

        try:

            cursor.execute(

            '''

            INSERT INTO users(

            full_name,

            email,

            password

            )

            VALUES(

            ?,?,?

            )

            ''',

            (

            full_name,

            email,

            password

            )

            )

            conn.commit()

            flash(

            'Registration Successful'

            )

            return redirect('/login')

        except:

            flash(

            'Email already exists'

            )

        finally:

            conn.close()

    return render_template(

    'register.html'

    )


# ---------------- AUTH CHECK ----------------

def is_logged_in():

    return 'user' in session


# ---------------- DASHBOARD ----------------

@app.route('/dashboard')

def dashboard():

    if not is_logged_in():

        return redirect('/login')

    stats = get_dashboard_stats()

    return render_template(

    'dashboard.html',

    total=stats['total'],

    eligible=stats['eligible'],

    ready=stats['ready'],

    average=stats['average']

    )


# ---------------- SCREENING ----------------

@app.route('/screening')

def screening():

    if not is_logged_in():

        return redirect('/login')

    return render_template(

    'screening.html'

    )


# ---------------- PREDICT ----------------

@app.route(

'/predict',

methods=['POST']

)

def predict():

    if not is_logged_in():

        return redirect('/login')

    candidate_name = request.form['name']

    cgpa = float(

    request.form['cgpa']

    )

    technical = int(

    request.form['technical']

    )

    aptitude = int(

    request.form['aptitude']

    )

    communication = int(

    request.form['communication']

    )

    projects = int(

    request.form['projects']

    )

    certifications = int(

    request.form['certifications']

    )

    github = int(

    request.form['github']

    )

    linkedin = int(

    request.form['linkedin']

    )

    values = [[

    cgpa,

    technical,

    aptitude,

    communication,

    projects,

    certifications,

    github,

    linkedin

    ]]

    prediction, cluster = predict_candidate(

    values

    )

    suitability = (

    'Highly Suitable'

    if prediction[0] == 1

    else

    'Needs Improvement'

    )

    cluster_names = {

    0:'Industry Ready',

    1:'Potential Candidate',

    2:'Needs Training'

    }

    score = int(

    (

    cgpa*10 +

    technical*5 +

    aptitude*5 +

    communication*5 +

    projects*4 +

    certifications*4 +

    github*3 +

    linkedin*3

    ) / 4

    )

    if score > 100:

        score = 100

    recommendations = recommendation_engine(

    cgpa,

    technical,

    communication,

    projects

    )

    conn = connect_db()

    cursor = conn.cursor()

    cursor.execute(

    '''

    INSERT INTO candidates(

    candidate_name,

    cgpa,

    technical,

    aptitude,

    communication,

    projects,

    certifications,

    github,

    linkedin,

    final_score,

    suitability,

    cluster_group

    )

    VALUES(

    ?,?,?,?,?,?,?,?,?,?,?,?

    )

    ''',

    (

    candidate_name,

    cgpa,

    technical,

    aptitude,

    communication,

    projects,

    certifications,

    github,

    linkedin,

    score,

    suitability,

    cluster_names[cluster[0]]

    )

    )

    conn.commit()

    conn.close()

    return render_template(

    'result.html',

    prediction=suitability,

    cluster=cluster_names[cluster[0]],

    score=score,

    recommendations=recommendations

    )


# ---------------- RESUME ----------------

@app.route('/resume')

def resume():

    if not is_logged_in():

        return redirect('/login')

    return render_template(

    'resume.html'

    )


# ---------------- ANALYZE RESUME ----------------

@app.route(

'/analyze_resume',

methods=['POST']

)

def resume_analysis():

    file = request.files['resume']

    filepath = os.path.join(

    app.config['UPLOAD_FOLDER'],

    file.filename

    )

    file.save(filepath)

    score, skills = analyze_resume(

    filepath

    )

    return render_template(

    'resume_result.html',

    score=score,

    skills=skills

    )


# ---------------- ANALYTICS ----------------

@app.route('/analytics')

def analytics():

    if not is_logged_in():

        return redirect('/login')

    stats = get_dashboard_stats()

    return render_template(

    'analytics.html',

    total=stats['total'],

    eligible=stats['eligible'],

    ready=stats['ready'],

    needs_training=max(

    stats['total']-

    stats['ready'],

    0

    )

    )


# ---------------- RANKING ----------------

@app.route('/ranking')

def ranking():

    conn = connect_db()

    cursor = conn.cursor()

    cursor.execute(

    '''

    SELECT *

    FROM candidates

    ORDER BY final_score DESC

    '''

    )

    candidates = cursor.fetchall()

    conn.close()

    return render_template(

    'ranking.html',

    candidates=candidates

    )


# ---------------- HISTORY ----------------

@app.route('/history')

def history():

    conn = connect_db()

    cursor = conn.cursor()

    cursor.execute(

    '''

    SELECT *

    FROM candidates

    ORDER BY created_at DESC

    '''

    )

    candidates = cursor.fetchall()

    conn.close()

    return render_template(

    'history.html',

    candidates=candidates

    )


# ---------------- LOGOUT ----------------

@app.route('/logout')

def logout():

    session.clear()

    return redirect('/login')


# ---------------- RUN ----------------

if __name__ == '__main__':

    os.makedirs(

    config.UPLOAD_FOLDER,

    exist_ok=True

    )

    app.run(

    debug=True

    )